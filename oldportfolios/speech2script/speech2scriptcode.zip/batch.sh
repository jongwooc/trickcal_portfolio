onmt-main --model_type Transformer --config config.yml --auto_config infer --features_file test.txt --predictions_file prediction.txt
#CUDA_VISIBLE_DEVICES=0,1 onmt-main --model_type Transformer --config config.yml --auto_config eval
